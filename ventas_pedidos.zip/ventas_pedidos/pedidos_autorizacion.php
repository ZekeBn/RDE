<?php
require_once("../includes/conexion.php");
require_once("../includes/funciones.php");

// Module name this file belongs to
$modulo = "1";
$submodulo = "2";   
$dirsup = "S";
require_once("../includes/rsusuario.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once("../includes/head_gen.php"); ?>
    <link rel="stylesheet" href="css/ventas_pedidos/pedidos_autorizacion.css">
</head>
<body class="nav-md">    
    <div class="container body">
        <div class="main_container">
            <?php require_once("../includes/menu_gen.php"); ?>
            <?php require_once("../includes/menu_top_gen.php"); ?>
            <div class="right_col" role="main">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Autorización de Pedidos</h3>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel"> 
                            <div class="x_content">
                                <!-- Filtros de búsqueda -->
                                <div class="row">
                                    <form id="formBusqueda">
                                        <div class="col-md-12 col-sm-6 form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Sucursal</label>
                                            <div class="col-md-5 col-sm-5 col-xs-9">
                                                <select name="sucursal" id="sucursal" class="form-control">
                                                    <option value="">Seleccione una Sucursal</option>
                                                    <?php
                                                    $consulta = "SELECT idsucu, nombre FROM sucursales;";
                                                    $rs = $conexion->Execute($consulta) or die(errorpg($conexion, $consulta));
                                                    while (!$rs->EOF) {
                                                        $row = $rs->fields;
                                                        echo "<option value=\"{$row['idsucu']}\">{$row['nombre']}</option>";
                                                        $rs->MoveNext();
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-sm-6 form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Fecha</label>
                                            <div class="col-md-5 col-sm-5 col-xs-9">
                                                <input type="date" name="fechapedido" id="fechapedido" class="form-control" />
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-sm-6 form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Número</label>
                                            <div class="col-md-5 col-sm-5 col-xs-9">
                                                <input type="text" name="numpedido" id="numpedido" class="form-control" />
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-sm-6 form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Cliente</label>
                                            <div class="col-md-5 col-sm-5 col-xs-9">
                                                <select name="cliente" id="cliente" class="form-control">
                                                    <option value="">Seleccione un Cliente</option>
                                                    <?php
                                                    $consulta = "SELECT idcliente, CONCAT(nombre, ' ', COALESCE(apellido, '')) as nom FROM cliente;";
                                                    $rs = $conexion->Execute($consulta) or die(errorpg($conexion, $consulta));
                                                    while (!$rs->EOF) {
                                                        $row = $rs->fields;
                                                        echo "<option value=\"{$row['idcliente']}\">{$row['nom']}</option>";
                                                        $rs->MoveNext();
                                                    }
                                                    ?>
                                                </select> 
                                            </div>
                                        </div>
                                        <div class="form-group text-center">
                                            <button type="button" id="buscar" class="btn btn-default"><span class="fa fa-search"></span> Buscar</button>
                                        </div>
                                    </form>
                                </div><br>

                                <!-- Tabla de pedidos -->
                                <div class="table-responsive">
                                    <table class="table table-striped jambo_table bulk_action" id="tablaPedidos">
                                        <thead>
                                            <tr>
                                                <th>Estado</th>
                                                <th>Serie</th>
                                                <th>Nro</th>
                                                <th>Fecha Pedido</th>
                                                <th>Cliente</th>
                                                <th>Monto Total</th>
                                                <th></th>
                                                <th>Autorización Comercial</th>
                                                <th></th>
                                                <th></th>
                                                <th>Autorización Cta Cte</th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td colspan="8">No se encontraron registros.</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <!-- End panel content -->
                        </div>                    
                    </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12" style="display:flex;justify-content:center;">
                    <button id="cancelar" type="button" class="btn btn-primary" onclick="window.location='pedidos.php'"><span class="fa fa-ban"></span> Cancelar</button>
                </div>
            </div>    
        </div>
    </div>

    <?php require_once("../includes/pie_gen.php"); ?>
    </div>
    <?php require_once("../includes/footer_gen.php"); ?>
    <!-- Scripts -->
    <script>
document.addEventListener("DOMContentLoaded", function () {
    const buscarButton = document.getElementById('buscar');
    const tablaPedidos = document.getElementById('tablaPedidos').querySelector('tbody');

    // Función para buscar los pedidos con los filtros
    function buscarPedidos() {
        const sucursal = document.getElementById('sucursal').value;
        const fechapedido = document.getElementById('fechapedido').value;
        const numpedido = document.getElementById('numpedido').value;
        const cliente = document.getElementById('cliente').value;

        const filtros = { sucursal, fechapedido, numpedido, cliente };
       
        fetch('pedidos_carga.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(filtros),
            
            })
            
            .then(response => response.json())
            .then(data => {
                console.log(response);

            tablaPedidos.innerHTML = ''; // Limpiar tabla antes de cargar nuevos resultados
            //console.log(data);
            
            if (data.length === 0) {
                tablaPedidos.innerHTML = '<tr><td colspan="11">No se encontraron registros.</td></tr>';
                return;
            }

            // Agregar filas a la tabla con los resultados de la búsqueda
            data.forEach(pedido => {
                const estadoTexto = {
                    L: 'Anulado',
                    C: 'Completo',
                    P: 'Pendiente',
                    A: 'Autorizado',
                }[pedido.estado] || 'Desconocido';

                tablaPedidos.innerHTML += `
                   <tr>
                        <!-- Serie del pedido -->
                        <td>${pedido.serie}</td>

                        <!-- Número del pedido -->
                        <td>${pedido.nro}</td>

                        <!-- Fecha del pedido -->
                        <td>${pedido.fecPedido}</td>

                        <!-- Cliente -->
                        <td>${pedido.cliente}</td>

                        <!-- Monto total -->
                        <td>${pedido.montoTotal}</td>

                        <!-- Autorización comercial -->
                        <td>
                            <input 
                                type="checkbox" 
                                class="form-check-input checkbox-autcomercial" 
                                data-idpedido="${pedido.idpedido}" />
                        </td>
                        <td>
                            <input type="text" class="form-control usuario-input-1" value = "${idusu}"readonly />
                        </td>
                        <td>
                            <input type="text" class="form-control fecha-input-1" readonly />
                        </td>

                        <!-- Autorización CTA CTE -->
                        <td>
                            <input 
                                type="checkbox" 
                                class="form-check-input checkbox-autoctacte" 
                                data-idpedido="${pedido.idpedido}" />
                        </td>
                        <td>
                            <input type="text" class="form-control usuario-input-2" readonly />
                        </td>
                        <td>
                            <input type="text" class="form-control fecha-input-2" readonly />
                        </td>
                        <td><button class="btn btn-primary btn-detalle" onclick="irADetalle(${pedido.idpedido})">
                                Ver Detalle     </button>
                        </td>
                    </tr>`;
            }
        );

            // Asignar el evento a los checkboxes después de cargar la tabla
            asignarEventosCheckbox(); 
        });
    }

    // Ejecutar la búsqueda automática al cargar la página
    buscarPedidos();

    // Evento para el botón de búsqueda
    buscarButton.addEventListener('click', function () {
        buscarPedidos(); // Realiza la búsqueda con los filtros cuando el usuario hace clic en "Buscar"
    });

    function asignarEventosCheckbox() {
        const checkbox1 = document.querySelectorAll('.checkbox-autcomercial');
        const checkbox2 = document.querySelectorAll('.checkbox-autoctacte');

        checkbox1.forEach(checkbox => {
            checkbox.addEventListener('change', function () {
                const row = this.closest('tr');
                const fechaInput = row.querySelector('.fecha-input-1');
                const usuarioInput = row.querySelector('.usuario-input-1');
                const idPedido = this.dataset.idpedido;

                if (this.checked) {
                    // Generar la fecha/hora actual
                    const fechaActual = new Date().toLocaleString();
                    fechaInput.value = fechaActual;

                    // Guardar los datos automáticamente
                    guardarDatos(idPedido, usuarioInput.value, fechaActual);
                } else {
                    // Vaciar los campos y limpiar el registro en la base de datos
                    fechaInput.value = "";
                    guardarDatos(idPedido, usuarioInput.value, "");
                }
            });
        });

        checkbox2.forEach(checkbox => {
            checkbox.addEventListener('change', function () {
                const row = this.closest('tr');
                const fechaInput = row.querySelector('.fecha-input-2');
                const usuarioInput = row.querySelector('.usuario-input-2');
                const idPedido = this.dataset.idpedido;

                if (this.checked) {
                    // Generar la fecha/hora actual
                    const fechaActual = new Date().toLocaleString();
                    fechaInput.value = fechaActual;

                    // Guardar los datos automáticamente
                    guardarDatos(idPedido, usuarioInput.value, fechaActual);
                } else {
                    // Vaciar los campos y limpiar el registro en la base de datos
                    fechaInput.value = "";
                    guardarDatos(idPedido, usuarioInput.value, "");
                }
            });
        });
    }

    function guardarDatos(idPedido, usuario1, fecha1, usuario2, fecha2) {
        const datos = { idPedido, usuario1, fecha1, usuario2, fecha2 };

        fetch('guardar_autorizacion.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(datos),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Datos guardados exitosamente');
            } else {
                console.error('Error al guardar los datos:', data.message);
            }
        })
        .catch(error => {
            console.error('Error en la solicitud:', error);
        });
    }
});

    </script>

<script>
    const usuarioActual = "<?php echo htmlspecialchars($usuario, ENT_QUOTES, 'UTF-8'); ?>";
</script>

</body>
</html>