<?php
require_once("../includes/conexion.php");
require_once("../includes/funciones.php");
// nombre del modulo al que pertenece este archivo
$modulo="1";
$submodulo="232";
$dirsup = 'S';
require_once("../includes/rsusuario.php");





?><div class="col-md-6 col-sm-6 form-group">
	<label class="control-label col-md-3 col-sm-3 col-xs-12">Ruc </label>
	<div class="col-md-9 col-sm-9 col-xs-12">
	<input type="text" name="ruc" id="ruc" value="<?php  if(isset($_POST['ruc'])){ echo htmlentities($_POST['ruc']); }else{ echo htmlentities($rs->fields['ruc']); }?>" placeholder="RUC" class="form-control" onkeypress="buscar_cliente_ruc(this.value);"  />                    
	</div>
</div>

<div class="col-md-6 col-sm-6 form-group">
	<label class="control-label col-md-3 col-sm-3 col-xs-12">Razon Social </label>
	<div class="col-md-9 col-sm-9 col-xs-12">
	<input type="text" name="razon_social" id="razon_social" value="<?php  if(isset($_POST['razon_social'])){ echo htmlentities($_POST['razon_social']); }else{ echo htmlentities($rs->fields['razon_social']); }?>" placeholder="Razon Social" class="form-control" onkeyup="buscar_cliente_rz(this.value);"  />                    
	</div>
</div>

<div class="clearfix"></div>
<hr />
<div id="result_clie"></div>